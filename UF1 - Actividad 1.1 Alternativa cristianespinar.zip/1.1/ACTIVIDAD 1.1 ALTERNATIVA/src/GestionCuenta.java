import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class GestionCuenta {

    // Carpeta y ficheros donde se guarda todo
    private static final File DIR_DATOS = new File("datos");
    private static final File F_TITULAR = new File(DIR_DATOS, "titular.txt");
    private static final File F_SALDO = new File(DIR_DATOS, "saldo.txt");
    private static final File F_MOV = new File(DIR_DATOS, "movimientos.txt");
    private static final DateTimeFormatter FMT_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static void main(String[] args) {
        // Uso BufferedReader para leer del teclado
        try (BufferedReader consola = new BufferedReader(new InputStreamReader(System.in))) {

            asegurarEstructura(); // Me aseguro de que exista la carpeta

            Titular titular;
            double saldo;

            // Si ya existen los datos los cargo, si no pido crear nueva cuenta
            if (F_TITULAR.exists() && F_SALDO.exists()) {
                titular = cargarTitular();
                saldo = cargarSaldo();
                System.out.println("Datos cargados correctamente.");
            } else {
                System.out.println("No se encontraron datos previos. Creando nueva cuenta...");
                titular = crearTitular(consola);
                guardarTitular(titular);
                saldo = 0.0;
                guardarSaldo(saldo);
                if (!F_MOV.exists()) F_MOV.createNewFile(); // creo el de movimientos vacío
                System.out.println("Cuenta creada con saldo inicial 0.0€");
            }

            boolean salir = false;
            // Bucle principal del menú
            while (!salir) {
                mostrarMenu();
                System.out.print("Seleccione una opción: ");
                String op = consola.readLine();

                switch (op) {
                    case "1":
                        // Mostrar saldo
                        System.out.println("Saldo actual: " + String.format("%.2f", saldo) + "€");
                        break;
                    case "2":
                        // Mostrar datos del titular
                        System.out.println(titular);
                        break;
                    case "3":
                        // Leer y mostrar movimientos desde el fichero
                        mostrarMovimientos();
                        break;
                    case "4":
                        // Hacer ingreso y actualizar saldo
                        saldo = realizarIngreso(consola, saldo);
                        break;
                    case "5":
                        // Hacer retirada y actualizar saldo
                        saldo = realizarRetirada(consola, saldo);
                        break;
                    case "6":
                        // Guardar saldo final y salir
                        guardarSaldo(saldo);
                        System.out.println("Cambios guardados. Fin.");
                        salir = true;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            }

        } catch (IOException e) {
            // Por si algo falla con archivos o lectura teclado
            System.out.println("Error general de E/S: " + e.getMessage());
        }
    }

    // Muestra el menú cada vez
    private static void mostrarMenu() {
        System.out.println("\n=== GESTIÓN DE CUENTA BANCARIA ===");
        System.out.println("1. Consultar saldo");
        System.out.println("2. Consultar datos del titular");
        System.out.println("3. Ver historial de movimientos");
        System.out.println("4. Realizar ingreso");
        System.out.println("5. Realizar retirada");
        System.out.println("6. Salir");
    }

    // Crea la carpeta si no existe
    private static void asegurarEstructura() throws IOException {
        if (!DIR_DATOS.exists()) {
            if (!DIR_DATOS.mkdir()) {
                throw new IOException("No se pudo crear la carpeta datos/");
            }
        }
    }

    // Pide datos por teclado para crear un titular nuevo
    private static Titular crearTitular(BufferedReader consola) throws IOException {
        System.out.print("Introduce el nombre completo del titular: ");
        String nombre = consola.readLine();
        System.out.print("Introduce el DNI: ");
        String dni = consola.readLine();
        System.out.print("Introduce el número de cuenta: ");
        String cuenta = consola.readLine();
        return new Titular(nombre, dni, cuenta);
    }

    // Guarda los datos del titular en su fichero (una línea cada dato)
    private static void guardarTitular(Titular t) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(F_TITULAR, StandardCharsets.UTF_8, false))) {
            bw.write(t.getNombreCompleto());
            bw.newLine();
            bw.write(t.getDni());
            bw.newLine();
            bw.write(t.getNumeroCuenta());
            bw.newLine();
        } catch (IOException e) {
            System.out.println("Error guardando titular: " + e.getMessage());
        }
    }

    // Carga el titular desde el fichero (lee 3 líneas)
    private static Titular cargarTitular() throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(F_TITULAR, StandardCharsets.UTF_8))) {
            String nombre = br.readLine();
            String dni = br.readLine();
            String cuenta = br.readLine();
            // Si falta algo, el formato está mal
            if (nombre == null || dni == null || cuenta == null) {
                throw new IOException("Formato incorrecto en titular.txt");
            }
            return new Titular(nombre, dni, cuenta);
        }
    }

    // Carga el saldo (si algo falla, devuelve 0)
    private static double cargarSaldo() {
        try (BufferedReader br = new BufferedReader(new FileReader(F_SALDO, StandardCharsets.UTF_8))) {
            String linea = br.readLine();
            if (linea == null) return 0.0;
            return Double.parseDouble(linea.trim());
        } catch (FileNotFoundException e) {
            System.out.println("No existe saldo.txt. Se asume 0.0");
            return 0.0;
        } catch (NumberFormatException e) {
            System.out.println("Formato de saldo inválido. Se asume 0.0");
            return 0.0;
        } catch (IOException e) {
            System.out.println("Error leyendo saldo: " + e.getMessage());
            return 0.0;
        }
    }

    // Guarda el saldo actual sobrescribiendo el fichero
    private static void guardarSaldo(double saldo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(F_SALDO, StandardCharsets.UTF_8, false))) {
            bw.write(String.format("%.2f", saldo));
        } catch (IOException e) {
            System.out.println("Error guardando saldo: " + e.getMessage());
        }
    }

    // Pide datos para ingreso y actualiza saldo
    private static double realizarIngreso(BufferedReader consola, double saldoActual) throws IOException {
        System.out.println("=== REALIZAR INGRESO ===");
        System.out.print("Cantidad: ");
        String txt = consola.readLine();
        double cantidad;
        try {
            cantidad = Double.parseDouble(txt);
        } catch (NumberFormatException e) {
            System.out.println("Cantidad inválida.");
            return saldoActual;
        }
        if (cantidad <= 0) {
            System.out.println("La cantidad debe ser positiva.");
            return saldoActual;
        }
        System.out.print("Concepto: ");
        String concepto = consola.readLine();
        double nuevoSaldo = saldoActual + cantidad;
        agregarMovimiento("INGRESO", cantidad, concepto);
        guardarSaldo(nuevoSaldo); // guardo inmediatamente
        System.out.println("Ingreso OK. Nuevo saldo: " + String.format("%.2f", nuevoSaldo) + "€");
        return nuevoSaldo;
    }

    // Pide datos para retirada y comprueba saldo suficiente
    private static double realizarRetirada(BufferedReader consola, double saldoActual) throws IOException {
        System.out.println("=== REALIZAR RETIRADA ===");
        System.out.print("Cantidad: ");
        String txt = consola.readLine();
        double cantidad;
        try {
            cantidad = Double.parseDouble(txt);
        } catch (NumberFormatException e) {
            System.out.println("Cantidad inválida.");
            return saldoActual;
        }
        if (cantidad <= 0) {
            System.out.println("La cantidad debe ser positiva.");
            return saldoActual;
        }
        if (cantidad > saldoActual) {
            System.out.println("Saldo insuficiente. Saldo: " + String.format("%.2f", saldoActual) + "€");
            return saldoActual;
        }
        System.out.print("Concepto: ");
        String concepto = consola.readLine();
        double nuevoSaldo = saldoActual - cantidad;
        agregarMovimiento("RETIRADA", cantidad, concepto);
        guardarSaldo(nuevoSaldo);
        System.out.println("Retirada OK. Nuevo saldo: " + String.format("%.2f", nuevoSaldo) + "€");
        return nuevoSaldo;
    }

    // Añade una línea al fichero de movimientos (modo append)
    private static void agregarMovimiento(String tipo, double cantidad, String concepto) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(F_MOV, StandardCharsets.UTF_8, true))) {
            if (!F_MOV.exists()) F_MOV.createNewFile();
            String fecha = LocalDate.now().format(FMT_FECHA);
            bw.write(tipo + ";" + String.format("%.2f", cantidad) + ";" + fecha + ";" + concepto);
            bw.newLine();
        } catch (IOException e) {
            System.out.println("Error guardando movimiento: " + e.getMessage());
        }
    }

    // Lee el fichero de movimientos y lo muestra línea a línea
    private static void mostrarMovimientos() {
        if (!F_MOV.exists()) {
            System.out.println("No hay movimientos.");
            return;
        }
        System.out.println("=== HISTORIAL DE MOVIMIENTOS ===");
        try (BufferedReader br = new BufferedReader(new FileReader(F_MOV, StandardCharsets.UTF_8))) {
            String linea;
            boolean alguno = false;
            while ((linea = br.readLine()) != null) {
                if (linea.isBlank()) continue;
                String[] p = linea.split(";", 4);
                if (p.length != 4) {
                    System.out.println("Línea inválida: " + linea);
                    continue;
                }
                System.out.println("Tipo: " + p[0] + " | Cantidad: " + p[1] + " | Fecha: " + p[2] + " | Concepto: " + p[3]);
                alguno = true;
            }
            if (!alguno) System.out.println("(sin movimientos)");
        } catch (IOException e) {
            System.out.println("Error leyendo movimientos: " + e.getMessage());
        }
    }
}
