public class Titular {
    // Datos básicos del titular de la cuenta
    private String nombreCompleto;
    private String dni;
    private String numeroCuenta;

    // Constructor para guardar los datos cuando se crea el titular
    public Titular(String nombreCompleto, String dni, String numeroCuenta) {
        this.nombreCompleto = nombreCompleto;
        this.dni = dni;
        this.numeroCuenta = numeroCuenta;
    }

    // Getters simples (solo devuelven el dato y ya)
    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getDni() {
        return dni;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    // Para mostrar los datos del titular de forma más clara
    @Override
    public String toString() {
        return "Titular:\nNombre: " + nombreCompleto + "\nDNI: " + dni + "\nCuenta: " + numeroCuenta;
    }
}
